"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Button, Tag } from "antd";
import {
  AuditOutlined,
  SolutionOutlined,
  SafetyCertificateOutlined,
  TeamOutlined,
  ArrowRightOutlined,
  SafetyOutlined,
} from "@ant-design/icons";
import styles from "./WhyChooseUsSection.module.css";

export default function WhyChooseUsSection() {
  const points = [
    {
      title: "Precision & Accuracy",
      description:
        "Every financial record is handled with utmost accuracy, leaving no detail overlooked.",
      icon: (
        <AuditOutlined className="text-xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      title: "Custom Solutions",
      description:
        "Services tailored around your unique needs, delivering personalised, insightful guidance.",
      icon: (
        <SolutionOutlined className="text-xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      title: "Transparency",
      description:
        "Clear, upfront pricing with no hidden charges - a straightforward, uncomplicated experience.",
      icon: (
        <SafetyCertificateOutlined className="text-xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      title: "Knowledgeable Team",
      description:
        "Certified, experienced professionals at the forefront of Australian tax legislation.",
      icon: (
        <TeamOutlined className="text-xl text-brand-primary dark:text-emerald-400" />
      ),
    },
  ];

  return (
    <section className="bg-gradient-to-b from-brand-bg-lighter to-white dark:from-zinc-900 dark:to-zinc-950 pt-12 pb-12 md:pt-20 md:pb-20 dark:border-zinc-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Team Graphic with Certified Badge (Col 5) */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-[460px]">
              {/* Soft Ambient Blur */}
              <div className="absolute inset-4 rounded-lg bg-emerald-200/50 dark:bg-emerald-950/40 blur-2xl -z-10" />

              {/* Main Image Frame */}
              <div className="relative rounded-lg overflow-hidden shadow-2xl shadow-emerald-950/10 border border-slate-200/80 dark:border-zinc-800 bg-white dark:bg-zinc-900 p-2">
                <Image
                  src="/images/services/home-Why-Choose-Us.webp"
                  alt="Financially Up Professional Team Meeting"
                  width={550}
                  height={450}
                  className="w-full h-auto object-cover rounded-lg"
                />
              </div>

              {/* Floating Certified Badge */}
              <div className="absolute -bottom-5 -right-2 sm:right-2 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md px-4 py-2.5 rounded-lg shadow-xl border border-emerald-100 dark:border-zinc-800 flex items-center gap-2.5 text-xs font-bold text-slate-800 dark:text-zinc-100 z-10">
                <span className="w-8 h-8 rounded-lg bg-brand-primary-soft dark:bg-emerald-950 text-brand-primary dark:text-emerald-400 flex items-center justify-center text-sm shrink-0">
                  <SafetyOutlined />
                </span>
                <div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    100% Tax Compliant
                  </div>
                  <div className="text-xs font-bold text-brand-primary dark:text-emerald-400">
                    Certified Tax Agents
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Clean Non-Boxed List Layout (Col 7) */}
          <div className="lg:col-span-7 space-y-6">
            <Tag color="green" className="brand-section-tag">
              Why Choose Us
            </Tag>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight leading-[1.2]">
              Precision meets personalised service.
            </h2>

            <p className="text-sm sm:text-base text-slate-600 dark:text-zinc-400 font-normal leading-relaxed">
              We empower Australian businesses and individuals with proactive
              tax strategies, stress-free lodgements, and full compliance.
            </p>

            {/* 4 Clean Non-Boxed Feature Rows */}
            <div className="pt-4 space-y-6">
              {points.map((point, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-4 pb-5 border-b border-slate-100 dark:border-zinc-800/80 last:border-none last:pb-0 group"
                >
                  {/* Soft Green Primary Icon Circle */}
                  <div className="w-11 h-11 rounded-lg bg-brand-primary-soft dark:bg-emerald-950/70 flex items-center justify-center shrink-0 mt-0.5 group-hover:scale-110 group-hover:bg-brand-primary transition-all duration-300">
                    <span className="group-hover:text-white transition-colors duration-300">
                      {point.icon}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div className="space-y-1">
                    <h3 className="text-base font-bold text-slate-900 dark:text-zinc-50 group-hover:text-brand-primary dark:group-hover:text-emerald-400 transition-colors">
                      {point.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed font-normal">
                      {point.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Ant Design CTA Button */}
            <div className="pt-4">
              <Link href="/resources/engagement-forms/individual-engagement-form">
                <Button
                  type="primary"
                  size="large"
                  icon={<ArrowRightOutlined />}
                  iconPlacement="end"
                  className="h-12 px-8 rounded-lg font-bold text-base bg-brand-primary hover:bg-brand-primary-hover shadow-md shadow-emerald-600/20 hover:scale-105 transition-all"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
