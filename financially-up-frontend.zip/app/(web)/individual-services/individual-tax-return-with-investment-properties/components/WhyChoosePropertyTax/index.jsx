"use client";

import React from "react";
import Link from "next/link";
import { Tag, Button } from "antd";
import {
  HomeOutlined,
  DollarOutlined,
  SolutionOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";

export default function WhyChoosePropertyTax() {
  const points = [
    {
      step: "01",
      tag: "Property Tax Expertise",
      title: "Investment Property Tax Knowledge",
      desc: "Our team possesses extensive knowledge in investment property taxation. We stay updated with the latest ATO guidelines and tax regulations specific to rental income to ensure full compliance.",
      icon: (
        <HomeOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "02",
      tag: "Deduction Optimization",
      title: "Maximizing Rental Tax Deductions",
      desc: "We specialize in identifying and maximizing rental property deductions including mortgage interest, repairs, maintenance, body corporate fees, land tax, and quantity surveyor depreciation schedules.",
      icon: (
        <DollarOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "03",
      tag: "Complex Schedules",
      title: "Handling Complex Rental Income",
      desc: "We easily navigate multiple investment properties, joint ownership split schedules, holiday rental rules, and Capital Gains Tax (CGT) calculations upon property disposal.",
      icon: (
        <SolutionOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
  ];

  return (
    <section className="bg-brand-primary-soft/30 dark:bg-zinc-900/30 pt-12 pb-12 md:pt-20 md:pb-20 border-t border-b border-slate-100 dark:border-zinc-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <Tag color="green" className="brand-section-tag">
            Why Choose Financially Up
          </Tag>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight leading-[1.2]">
            Why Choose Financially Up for Your Individual Tax Returns with
            Investment Properties?
          </h2>

          <p className="text-sm text-slate-500 dark:text-zinc-400">
            Expert property tax accountants helping rental property owners
            optimize negative gearing and claim every eligible deduction.
          </p>
        </div>

        {/* 3 Executive Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-14">
          {points.map((item, idx) => (
            <div
              key={idx}
              className="group relative bg-white dark:bg-zinc-900 p-8 rounded-lg border border-slate-200/80 dark:border-zinc-800 shadow-sm flex flex-col justify-between hover:border-brand-primary hover:shadow-xl hover:shadow-emerald-600/10 hover:-translate-y-1.5 transition-all duration-300 overflow-hidden"
            >
              {/* Top Accent Gradient Bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-brand-primary via-emerald-400 to-brand-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-lg bg-brand-primary-soft dark:bg-emerald-950/80 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    {item.icon}
                  </div>
                  <span className="text-2xl font-black text-slate-200 dark:text-zinc-800 group-hover:text-brand-primary/30 transition-colors">
                    {item.step}
                  </span>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-brand-primary dark:text-emerald-400">
                    {item.tag}
                  </span>
                  <h3 className="text-xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight mt-0.5">
                    {item.title}
                  </h3>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-300 leading-relaxed font-normal">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Center CTA Button */}
        <div className="text-center">
          <Link href="/book-an-appointment">
            <Button
              type="primary"
              size="large"
              icon={<ArrowRightOutlined />}
              iconPlacement="end"
              className="h-12 px-8 rounded-lg font-bold text-base bg-brand-primary hover:bg-brand-primary-hover shadow-md shadow-emerald-600/20 hover:scale-105 transition-all"
            >
              Book an Appointment
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
