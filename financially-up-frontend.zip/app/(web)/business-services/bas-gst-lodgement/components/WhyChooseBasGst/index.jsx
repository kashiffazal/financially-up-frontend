"use client";

import React from "react";
import Link from "next/link";
import { Button, Tag } from "antd";
import {
  ArrowRightOutlined,
  FileProtectOutlined,
  AuditOutlined,
  DollarOutlined,
  ExclamationCircleOutlined,
  UsergroupAddOutlined,
  SafetyCertificateOutlined,
} from "@ant-design/icons";

export default function WhyChooseBasGst() {
  const whyChoosePoints = [
    {
      step: "01",
      tag: "BAS Expertise",
      title: "Comprehensive Knowledge of BAS & GST",
      desc: "With years of experience assisting clients with BAS and GST compliance, we stay updated with the latest ATO requirements to guarantee accurate quarterly activity statement lodgement.",
      icon: (
        <FileProtectOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "02",
      tag: "Entity Specific",
      title: "Tailored Entity-Specific Reporting",
      desc: "Different business structures have unique GST reporting obligations. We tailor BAS and GST lodgements specifically for sole traders, partnerships, trusts, and PTY LTD companies.",
      icon: (
        <SafetyCertificateOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "03",
      tag: "Audit Defense",
      title: "Minimizing Errors & ATO Audit Risks",
      desc: "Mistakes in GST calculations cause severe penalties. Our meticulous reconciliation of Xero/MYOB/QuickBooks bank feeds eliminates errors before submission to the ATO portal.",
      icon: (
        <AuditOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "04",
      tag: "Payroll & PAYGW",
      title: "Reporting Employee Salaries & PAYGW",
      desc: "We handle gross wages (W1) and tax withheld (W2) reporting aligned with Single Touch Payroll (STP Phase 2) so your employee payroll compliance is always 100% accurate.",
      icon: (
        <UsergroupAddOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "05",
      tag: "PAYG Instalments",
      title: "Income Tax Instalments (IAS) Management",
      desc: "We calculate monthly or quarterly PAYG Income Tax Instalments to prevent surprise year-end income tax bills and keep cash flow predictable.",
      icon: (
        <DollarOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
    {
      step: "06",
      tag: "Deadline Extension",
      title: "Avoiding ATO Late Lodgement Penalties",
      desc: "Lodging your activity statement through our registered BAS agent portal automatically grants you an extra 4-week ATO lodgement & payment deadline extension!",
      icon: (
        <ExclamationCircleOutlined className="text-2xl text-brand-primary dark:text-emerald-400" />
      ),
    },
  ];

  return (
    <section className="bg-brand-primary-soft/30 dark:bg-zinc-900/30 pt-12 pb-12 md:pt-20 md:pb-20 border-t border-b border-slate-100 dark:border-zinc-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <Tag color="green" className="brand-section-tag">
            Why Choose Us
          </Tag>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight leading-[1.2]">
            Why Choose Financially Up for Your BAS/GST lodgement?
          </h2>

          <p className="text-sm text-slate-500 dark:text-zinc-400">
            Registered BAS agents providing penalty avoidance, extra 4-week ATO
            lodgement extensions, and error-free GST activity statements.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-14">
          {whyChoosePoints.map((item, idx) => (
            <div
              key={idx}
              className="group relative bg-white dark:bg-zinc-900 p-8 rounded-lg border border-slate-200/80 dark:border-zinc-800 shadow-sm flex flex-col justify-between hover:border-brand-primary hover:shadow-xl hover:shadow-emerald-600/10 hover:-translate-y-1.5 transition-all duration-300 overflow-hidden"
            >
              {/* Top Accent Gradient Bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-brand-primary via-emerald-400 to-brand-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-lg bg-brand-primary-soft dark:bg-emerald-950/80 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    {item.icon}
                  </div>
                  <span className="text-2xl font-black text-slate-200 dark:text-zinc-800 group-hover:text-brand-primary/30 transition-colors">
                    {item.step}
                  </span>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-brand-primary dark:text-emerald-400">
                    {item.tag}
                  </span>
                  <h3 className="text-xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight mt-0.5">
                    {item.title}
                  </h3>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-300 leading-relaxed font-normal">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/book-an-appointment">
            <Button
              type="primary"
              size="large"
              icon={<ArrowRightOutlined />}
              iconPlacement="end"
              className="h-12 px-8 rounded-lg font-bold text-base bg-brand-primary hover:bg-brand-primary-hover shadow-md shadow-emerald-600/20 hover:scale-105 transition-all"
            >
              Book an Appointment
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
