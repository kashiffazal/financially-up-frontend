"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Button, Tag } from "antd";
import {
  ArrowRightOutlined,
  CheckCircleFilled,
  TeamOutlined,
} from "@ant-design/icons";

export default function PartnershipOverview() {
  const highlights = [
    "Accurate profit & loss distribution allocation among partners",
    "Instant asset write-off & joint property depreciation",
    "Individual partner tax return integration",
    "Registered CPA tax agent review for 100% ATO compliance",
  ];

  return (
    <section className="bg-white dark:bg-zinc-950 pt-12 pb-12 md:pt-20 md:pb-20 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="lg:col-span-6 space-y-6">
            <Tag color="green" className="brand-section-tag">
              Partnership Specialists
            </Tag>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-zinc-50 tracking-tight leading-[1.2]">
              Expert Assistance for Partnership Tax Returns
            </h2>

            <p className="text-base text-slate-600 dark:text-zinc-300 leading-relaxed font-normal">
              At Financially Up, we specialize in providing expert assistance
              with partnership tax returns. Our experienced team of tax
              professionals understands the unique tax obligations and
              complexities associated with partnerships. Whether you have a
              general partnership, limited partnership, or limited liability
              partnership, we have the expertise to simplify your tax
              compliance.
            </p>

            {/* 2x2 Grid Highlights Chips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {highlights.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-slate-50 dark:bg-zinc-900 border border-slate-100 dark:border-zinc-800 flex items-center gap-2.5 text-xs font-semibold text-slate-700 dark:text-zinc-200 hover:bg-brand-primary-soft transition-all"
                >
                  <CheckCircleFilled className="text-brand-primary dark:text-emerald-400 text-sm shrink-0" />
                  <span className="leading-snug">{item}</span>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <Link href="/book-an-appointment">
                <Button
                  type="primary"
                  size="large"
                  icon={<ArrowRightOutlined />}
                  iconPlacement="end"
                  className="h-12 px-8 rounded-lg font-bold text-base bg-brand-primary hover:bg-brand-primary-hover shadow-md shadow-emerald-600/20 hover:scale-105 transition-all"
                >
                  Book an Appointment
                </Button>
              </Link>
            </div>
          </div>

          {/* Right Graphic Frame with Floating Badge */}
          <div className="lg:col-span-6 flex justify-center">
            <div className="relative w-full rounded-lg overflow-hidden shadow-2xl border border-slate-200/80 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 p-3">
              <Image
                src="/images/services/Partnership.webp"
                alt="Expert Assistance for Partnership Tax Returns"
                width={550}
                height={550}
                className="w-full h-[550px] object-cover rounded-lg"
              />

              {/* Floating Trust Badge */}
              <div className="absolute bottom-6 right-6 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md px-3.5 py-2 rounded-lg shadow-lg border border-slate-200/80 dark:border-zinc-800 flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-zinc-50 z-10">
                <TeamOutlined className="text-brand-primary dark:text-emerald-400 text-sm" />
                <span>Partner Profit Splits</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
